import React, { useState, useEffect } from "react";
import { Container, Nav, Navbar, NavDropdown } from "react-bootstrap";
import { Link, Outlet } from "react-router"; 

import crest from '../../assets/uw-crest.svg'
import BadgerLoginStatusContext from "../contexts/BadgerLoginStatusContext";

function BadgerLayout(props) {

    // Step 6: Initialize from sessionStorage so the login persists on refresh
    const [loginStatus, setLoginStatus] = useState(
        JSON.parse(sessionStorage.getItem("loggedIn") || "false")
    );

    const [chatrooms, setChatrooms] = useState([]);

    useEffect(() => {
        fetch("https://cs571api.cs.wisc.edu/rest/s26/hw6/chatrooms", {
            // FIXED: Changed 'header' to 'headers'
            headers: {
                "X-CS571-ID": "bid_8ec5202e0b08791aea5ceb71c5b95b400d9d5dc79b22aacda688012f647f367e" 
            }
        })
        .then(res => {
            if (res.status === 200) {
                return res.json();
            } else {
                throw new Error("Unauthorized");
            }
        })
        .then(data => {
            // Safeguard: Ensure data is an array before setting state
            if (Array.isArray(data)) {
                setChatrooms(data);
            }
        })
        .catch(err => {
            console.error("Failed to fetch chatrooms: ", err);
            setChatrooms([]); // Fallback to empty array to prevent crash
        });
    }, [])

    return (
        <div>
            <Navbar bg="dark" variant="dark">
                <Container>
                    <Navbar.Brand as={Link} to="/">
                        <img
                            alt="BadgerChat Logo"
                            src={crest}
                            width="30"
                            height="30"
                            className="d-inline-block align-top"
                        />{' '}
                        BadgerChat
                    </Navbar.Brand>
                    <Nav className="me-auto">
                        <Nav.Link as={Link} to="/">Home</Nav.Link>
                        
                        {/* Step 6: Conditional Rendering */}
                        {loginStatus ? (
                            <Nav.Link as={Link} to="logout">Logout</Nav.Link>
                        ) : (
                            <>
                                <Nav.Link as={Link} to="login">Login</Nav.Link>
                                <Nav.Link as={Link} to="register">Register</Nav.Link>
                            </>
                        )}

                        <NavDropdown title="Chatrooms">
                            {
                                chatrooms.map((room) => (
                                <NavDropdown.Item
                                    key={room}
                                    as={Link}
                                    to={`chatrooms/${room}`}
                                >
                                    {room}
                                </NavDropdown.Item>
                                ))
                            }
                        </NavDropdown>
                    </Nav>
                </Container>
            </Navbar>
            <div style={{ margin: "1rem" }}>
                <BadgerLoginStatusContext.Provider value={[loginStatus, setLoginStatus]}>
                    <Outlet />
                </BadgerLoginStatusContext.Provider>
            </div>
        </div>
    );
}

export default BadgerLayout;