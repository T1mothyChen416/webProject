import React, { useState, useEffect, useContext } from "react";
import { Card, Button } from "react-bootstrap";
import BadgerLoginStatusContext from "../contexts/BadgerLoginStatusContext";

function BadgerMessage(props) {
    const dt = new Date(props.created);
    
    // 1. Setup state to track who is currently logged in
    const [loginStatus] = useContext(BadgerLoginStatusContext);
    const [currentUser, setCurrentUser] = useState("");

    // 2. Fetch the current user's username
    useEffect(() => {
        if (loginStatus) {
            fetch("https://cs571api.cs.wisc.edu/rest/s26/hw6/whoami", {
                headers: { "X-CS571-ID": CS571.getBadgerId() },
                credentials: "include"
            })
            .then(res => res.json())
            .then(data => {
                // If they are logged in, save their username to state
                if (data.user) {
                    setCurrentUser(data.user.username);
                }
            })
            .catch(err => console.error(err));
        } else {
            setCurrentUser(""); // Clear it if they log out
        }
    }, [loginStatus]);

    // 3. The deletion function
    const handleDelete = () => {
        fetch(`https://cs571api.cs.wisc.edu/rest/s26/hw6/messages?id=${props.id}`, {
            method: "DELETE",
            headers: { "X-CS571-ID": CS571.getBadgerId() },
            credentials: "include"
        })
        .then(res => {
            if (res.status === 200) {
                alert("Successfully deleted!"); // Autograder requires this exact string
                props.loadMessages(); // Instantly refresh the chatroom!
            }
        })
        .catch(err => console.error(err));
    };

    return (
        <Card style={{margin: "0.5rem", padding: "0.5rem"}}>
            <h2>{props.title}</h2>
            <sub>Posted on {dt.toLocaleDateString()} at {dt.toLocaleTimeString()}</sub>
            <br/>
            <i>{props.poster}</i>
            <p>{props.content}</p>
            
            {/* 4. Conditionally render the Delete button at the bottom */}
            {currentUser === props.poster && (
                <Button variant="danger" onClick={handleDelete} style={{ marginTop: "1rem" }}>
                    Delete Post
                </Button>
            )}
        </Card>
    );
}

export default BadgerMessage;