import React, { useEffect, useState, useContext } from "react"
import { Row, Col, Pagination, Form, Button } from "react-bootstrap"
import BadgerMessage from "./BadgerMessage"
import BadgerLoginStatusContext from "../contexts/BadgerLoginStatusContext"

export default function BadgerChatroom(props) {

    const [messages, setMessages] = useState([]);
    const [page, setPage] = useState(1);
    
    // --- NEW: State for the post form and global login status ---
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");
    const [loginStatus] = useContext(BadgerLoginStatusContext);

    const loadMessages = () => {
        fetch(`https://cs571api.cs.wisc.edu/rest/s26/hw6/messages?chatroom=${props.name}&page=${page}`, {
            headers: {
                "X-CS571-ID": CS571.getBadgerId()
            }
        }).then(res => res.json()).then(json => {
            setMessages(json.messages)
        })
    };

    useEffect(loadMessages, [props, page]);

    // --- NEW: Handle post submission ---
    const handleCreatePost = (e) => {
        e.preventDefault();

        if (!title || !content) {
            alert("You must provide both a title and content!");
            return;
        }

        fetch(`https://cs571api.cs.wisc.edu/rest/s26/hw6/messages?chatroom=${props.name}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CS571-ID": CS571.getBadgerId()
            },
            credentials: "include",
            body: JSON.stringify({
                title: title,
                content: content
            })
        })
        .then(res => res.json())
        .then(data => {
            alert("Successfully posted!");
            setTitle(""); // Clear the title input
            setContent(""); // Clear the content input
            setPage(1); // Jump to page 1 to see the new post
            loadMessages(); // Fetch the messages immediately without reloading the page!
        })
        .catch(err => console.error(err));
    };

    return <>
        <h1>{props.name} Chatroom</h1>
        
        {/* --- NEW: Conditional Rendering for the Form --- */}
        {loginStatus ? (
            <Form onSubmit={handleCreatePost}>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="post-title">Title</Form.Label>
                    <Form.Control 
                        id="post-title" 
                        type="text" 
                        value={title} 
                        onChange={e => setTitle(e.target.value)} 
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="post-content">Content</Form.Label>
                    <Form.Control 
                        id="post-content" 
                        as="textarea" 
                        rows={3} 
                        value={content} 
                        onChange={e => setContent(e.target.value)} 
                    />
                </Form.Group>
                <Button variant="primary" type="submit">
                    Create Post
                </Button>
            </Form>
        ) : (
            <p>You must be logged in to post!</p>
        )}
        
        <hr/>
        {
            messages.length > 0 ?
                <>
                    <Row>
                        {messages.map(msg => (
                            <Col key={msg.id} xs={12} md={6} lg={4} xl={3}>
                                <BadgerMessage 
                                    id={msg.id}
                                    title={msg.title}
                                    poster={msg.poster}
                                    content={msg.content}
                                    created={msg.created}
                                    loadMessages={loadMessages}
                                />
                            </Col>
                        ))}
                    </Row>
                </>
                :
                <>
                    <p>There are no messages on this page yet.</p>
                </>
        }
        <Pagination className="mt-4 justify-content-center">
            <Pagination.Item active={page === 1} onClick={() => setPage(1)}>1</Pagination.Item>
            <Pagination.Item active={page === 2} onClick={() => setPage(2)}>2</Pagination.Item>
            <Pagination.Item active={page === 3} onClick={() => setPage(3)}>3</Pagination.Item>
            <Pagination.Item active={page === 4} onClick={() => setPage(4)}>4</Pagination.Item>
        </Pagination>
    </>
}