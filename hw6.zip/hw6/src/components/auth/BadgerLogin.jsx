import React, { useRef, useContext } from 'react';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router'; 
import BadgerLoginStatusContext from '../contexts/BadgerLoginStatusContext';

export default function BadgerLogin() {
    const navigate = useNavigate();
    const [loginStatus, setLoginStatus] = useContext(BadgerLoginStatusContext);

    const usernameRef = useRef();
    const pinRef = useRef();

    const handleLogin = (e) => {
        e.preventDefault(); 

        const username = usernameRef.current.value;
        const pin = pinRef.current.value;

        if (!username || !pin) {
            alert("You must provide both a username and pin!");
            return;
        }

        const pinRegex = /^\d{7}$/;
        if (!pinRegex.test(pin)) {
            alert("Your pin is not a 7-digit number!");
            return;
        }

        fetch("https://cs571api.cs.wisc.edu/rest/s26/hw6/login", {
            method: "POST",
            headers: { // plural
                "Content-Type": "application/json",
                "X-CS571-ID": "bid_8ec5202e0b08791aea5ceb71c5b95b400d9d5dc79b22aacda688012f647f367e"
            },
            credentials: "include", 
            body: JSON.stringify({
                username: username,
                pin: pin
            })
        })
        .then(res => {
            if (res.status === 401) {
                alert("Incorrect username or pin!");
                throw new Error("Incorrect credentials");
            }
            if (res.status === 200) {
                alert("You have been successfully logged in!");
                setLoginStatus(true);
                sessionStorage.setItem("loggedIn", JSON.stringify(true));
                navigate("/");
            }
        })
        .catch(err => console.error(err));
    };

    return <>
        <h1>Login</h1>
        <Form onSubmit={handleLogin}>
            <Form.Group className="mb-3">
                <Form.Label htmlFor="login-username">Username</Form.Label>
                <Form.Control 
                    id="login-username"
                    name="username" // Added for autograder
                    type="text"
                    ref={usernameRef} 
                />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label htmlFor="login-pin">Pin</Form.Label>
                <Form.Control 
                    id="login-pin"
                    name="pin" // Added for autograder
                    type="password" 
                    ref={pinRef}
                />
            </Form.Group>

            <Button variant="primary" type="submit">
                Login
            </Button>
        </Form>
    </>
}