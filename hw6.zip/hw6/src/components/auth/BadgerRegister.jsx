import React, { useState, useContext } from 'react';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router'; 
import BadgerLoginStatusContext from '../contexts/BadgerLoginStatusContext';

export default function BadgerRegister() {
    const [username, setUsername] = useState("");
    const [pin, setPin] = useState("");
    const [repeatPin, setRepeatPin] = useState("");
    const navigate = useNavigate();
    const [loginStatus, setLoginStatus] = useContext(BadgerLoginStatusContext);
    
    const handleRegister = (e) => {
        e.preventDefault(); 

        if (!username || !pin) {
            alert("You must provide both a username and pin!");
            return;
        }

        const pinRegex = /^\d{7}$/;
        if (!pinRegex.test(pin) || !pinRegex.test(repeatPin)) {
            alert("Your pin must be a 7-digit number!");
            return;
        }

        if (pin !== repeatPin) {
            alert("Your pins do not match!");
            return;
        }

        fetch("https://cs571api.cs.wisc.edu/rest/s26/hw6/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                // FIXED: Plural 'headers' and used your specific Badger ID string
                "X-CS571-ID": "bid_8ec5202e0b08791aea5ceb71c5b95b400d9d5dc79b22aacda688012f647f367e"
            },
            credentials: "include", 
            body: JSON.stringify({
                username: username,
                pin: pin
            })
        })
        .then(res => {
            if (res.status === 409) {
                alert("That username has already been taken!");
                throw new Error("Username taken");
            }
            if (res.status === 200) {
                alert("You have successfully registered!");
                setLoginStatus(true); 
                sessionStorage.setItem("loggedIn", JSON.stringify(true)); 
                navigate("/"); 
            }
        })
        .catch(err => console.error(err));
    };

    return <>
        <h1>Register</h1>
        <Form onSubmit={handleRegister}>
            <Form.Group className="mb-3">
                <Form.Label htmlFor="register-username">Username</Form.Label>
                <Form.Control 
                    id="register-username"
                    name="username" // Added for autograder
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label htmlFor="register-pin">Pin</Form.Label>
                <Form.Control 
                    id="register-pin"
                    name="pin" // Added for autograder
                    type="password" 
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label htmlFor="register-repeat-pin">Repeat Pin</Form.Label>
                <Form.Control 
                    id="register-repeat-pin"
                    name="repeat-pin" // Added for autograder
                    type="password" 
                    value={repeatPin}
                    onChange={(e) => setRepeatPin(e.target.value)}
                />
            </Form.Group>

            <Button variant="primary" type="submit">
                Register
            </Button>
        </Form>
    </>
}