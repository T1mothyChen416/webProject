import React, { useEffect, useContext } from 'react';
import BadgerLoginStatusContext from '../contexts/BadgerLoginStatusContext';

export default function BadgerLogout() {
    // 1. Grab the context setter to update the global state
    const [loginStatus, setLoginStatus] = useContext(BadgerLoginStatusContext);
    
    useEffect(() => {
        fetch('https://cs571api.cs.wisc.edu/rest/s26/hw6/logout', {
            method: 'POST',
            headers: {
                "X-CS571-ID": CS571.getBadgerId()
            },
            credentials: "include"
        }).then(res => res.json()).then(json => {
            // 2. Clear the logged-in state from context and sessionStorage
            setLoginStatus(false);
            sessionStorage.removeItem("loggedIn"); 
        })
    }, []); // Empty array ensures this only runs once when the component mounts

    return <>
        <h1>Logout</h1>
        <p>You have been successfully logged out.</p>
    </>
}